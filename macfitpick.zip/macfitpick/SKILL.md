---
name: macfitpick  
description: Recommend a McDonald's meal combo that satisfies a user's protein target and budget while respecting dietary restrictions (e.g., no chicken). This skill should be used when the user states a protein goal, a spending limit, and/or food exclusions and wants a McDonald's suggestion with item list, total price, estimated protein/carbs/calories, and eating tips. It always pulls live nutrition from the mcd-mcp list-nutrition-foods tool and per-store prices from query-meals, and never invents those values.
---

# MacFitPick

## Overview

MacFitPick turns user inputs — a protein target, a budget, dietary restrictions, and the scenario they are in — into a concrete McDonald's meal recommendation. It queries the connected **mcd-mcp** server for nutrition data and per-store prices, then selects the combo that best satisfies the constraints.

The skill never estimates prices or nutrition from memory. Every monetary and nutritional figure comes directly from mcd-mcp responses or the bundled recommender script. WorkBuddy's added value is scenario handling, combination logic, and formatted advice.

## When to Use

Trigger this skill when the user:

- Asks for a McDonald's meal that fits a fitness/diet goal (e.g., "我要 40g 蛋白质，预算 35 元，不吃鸡肉").
- Provides any combination of: a protein target (g), a budget (¥), and dietary exclusions (忌口 like 不吃牛肉 / 不吃猪肉 / 不要酱).
- Asks for coupon-aware / budget-saving orders, multi-person group orders, weight-loss friendly picks, or priority-based protein sources (鱼>牛>猪).
- Wants the price, macros (蛋白质 / 碳水 / 热量), and practical eating advice for a McDonald's order.

Do **not** use this skill for non-McDonald's restaurants or general nutrition education without an order.

## Dynamic Scenarios (多态场景处理)

Before running the Workflow, classify the request into one or more scenarios. Scenarios can **combine** (e.g. 多人拼单 + 省钱); handle all that apply.

### 场景 1：省钱 / 用优惠券

- Detect: 提到「优惠 / 省钱 / 便宜 / 券 / 性价比 / 满减」。
- Handling: 在门店价格之外，调用 `query-promotions` / `query-store-coupons` 获取可用优惠；对候选组合用 `calculate-price`（带 `couponId` / `couponCode`）算**券后价**。
- 输出时做**直购价 vs 券后价**对比，推荐更优者；注明券的门槛（满减条件、随单购早餐卡需绑定等），实际到手价以 calculate-price 返回为准。

### 场景 2：单一目标 + 优先级

- Detect: 用户给出明确的优先序（如「鱼>牛>猪」「优先牛肉」）或单一硬性目标。
- Handling: 把优先级编码进筛选规则——优先只保留最高优先蛋白来源跑脚本。
- 若当前时段/门店**没有**该类餐品（如早餐菜单无鱼），**诚实告知无法满足该优先级**，再给次优方案，并明确说明「为什么退而求其次」（缺什么、差在哪）。绝不假装满足。

### 场景 3：多人拼单

- Detect: 提到「N 个人 / 一起 / 拼单 / 带小朋友 / 大家忌口不同」。
- Handling: **按人拆分**。为每个人单独解析约束（忌口 / 目标 / 份量），对同一份菜单文件各跑一次 `recommend.py`（不同 `--restrictions` / `--protein` / `--budget`）。
- 输出**按人分组，明确「谁吃哪份」**；小朋友推荐小份/儿童友好款（玉米杯、苹果片、牛奶等），不推咖啡因和碳酸。
- **如果人群中有小朋友，必须为其搭配一份主食**（如开心乐园餐、小汉堡、玉米杯），并确保无辣、无咖啡因，**不能只给零食或饮品**。
- 每人小计 + 总价须 <= 总预算；不要把所有人混在一个组合里。

### 场景 4：减肥 / 低卡低GI

- Detect: 提到「减脂 / 减肥 / 控卡 / 低卡 / 低GI / 低碳」。
- 主目标从「蛋白质最大化」切换&#x4E3A;**「热量最低」**：默认去酱（或分装另放）、面包可建议去一面包（开放堡式吃法）、饮料一律无糖（无糖可乐 / 鲜萃咖啡 / 矿泉水）、配菜换玉米杯 / 苹果片而非薯条。
- 跑脚本时可放低 `--protein` 下限（守住用户可接受的最低蛋白即可）；若需严格热量优先，可把脚本候选排序键临时改为 `(calories, price)`（一处小改），或对脚本输出的少量候选按热量升序重排后再呈现。
- 输出强调每份热量、蛋白质下限是否守住、以及做了哪些「去/换」的实操调整。

### 场景 5：无解兜底

- Detect: 脚本返回 `status != ok`（`below_target` / `over_budget` / `no_price_data`），或约束明显冲突（预算极低但要求极高）。
- Handling: **绝不编造一个"满足所有约束"的方案**。给出 1–2 个最接近的备选，明确说「满足了什么、差在哪」（如：蛋白差 5g / 超预算 ¥3 / 该时段无此品类）。
- 同时给出用户可做的调整选项：加预算、放宽某项忌口、换时段（早餐/午餐菜单不同）、换门店。

## Output Format (动态格式规范)

- **根据场景灵活组织语言，不套固定模板**：省钱场景突出券后对比；多人场景按人分块；减脂场景突出热量与「去/换」调整；无解场景突出差距与可选项。
- 无论何种场景，输出**必须包含四要素**：
  1. **推荐组合（带价格）**——单品价格 + 总价；用了券则标注券后价；
  2. **核心营养**——蛋白质 / 碳水 / 热量（多人场景按人给出）；
  3. **实操建议**——去酱 / 换配菜 / 无糖饮料等，来自脚本 `advice` + 场景规则；
  4. **门店信息**——门店名称 / 地址 / storeCode。
- 简单需求可以精炼成几行，复杂需求（多人 / 无解）分块呈现。
- 所有数字一律来自 mcd-mcp 数据或脚本输出，标注为估算值（基于菜单数据）。

## Workflow

### 1. Parse the constraints and identify scenarios

Extract from the user message:

- `protein_target` — grams (number, optional in 低卡场景).
- `budget` — CNY (number, optional).
- `restrictions` — free-text 忌口, translated into exclusion **keywords** (e.g., "不吃鸡肉" → `["鸡","chicken"]`; "不吃猪肉" → `["猪","pork"]`; "不要酱" → `["酱","sauce"]`).
- Scenario tags from the Dynamic Scenarios section (省钱 / 优先级 / 多人 / 低卡 / 无解兜底).

If the protein target is missing but the scenario implies one (e.g. 增肌), ask the user before proceeding. If the budget is missing but a store/location is known, continue and let the script rank by nutrition only.

### 2. Pull data in parallel (speed rule)

- **必须并行调用**：`mcp__mcd-mcp__list-nutrition-foods`（无参数）与 `mcp__mcd-mcp__query-nearby-stores`（`searchType=2` + `city`/`keyword`，或 `searchType=1` 收藏门店；`beType=1` 到店自取）在同一条消息里**并行发起**，不要串行等待。
- 营养数据返回的是 **TEXT 文本块**（非 JSON），把原始 `data` 字符串保存到本地文件，如 `mcd_nutrition.txt`。

### 3. Get per-store prices (needed for 总价)

1. 从返回门店中选一家（用户无偏好时取最近的一家；多家且用户可能在意时先让用户选）。
2. 调用 **一次** `mcp__mcd-mcp__query-meals`（`storeCode`, `orderType=1`, `beType=1`；麦乐送/团餐场景才走 `orderType=2` 路径）——其返回已含全部分类与全量价格，**不要循环调用类目子工具**（见 Speed 规则 3）。
3. 提取 `{name, price}` 对写入 `mcd_prices.json`（仅一次落盘，直接进脚本）。
4. 场景 1（优惠券）在此步骤**并行**调用 `query-store-coupons`。

若用户不给位置也不愿提供门店，跳过本步骤——脚本会降级为纯营养推荐并明确说明总价待确认。**绝不编造价格**。

`query-meals` 价格单位可能是「分」；脚本会按中位数自动识别并换算为「元」，输出时如发生换算需注明。

### 4. Run the recommender (compute via script, never in your head)

**严禁在脑内暴力枚举组合或心算营养加总**——所有组合枚举、过滤、评分、加总必须交给 `scripts/recommend.py`：

```bash
python3 scripts/recommend.py \
  --menu mcd_nutrition.txt \
  --prices mcd_prices.json \
  --protein <target> \
  --budget <budget> \
  --restrictions "鸡,chicken" \
  --max-combo 3
```

- 多人拼单（场景 3）：**每人跑一次**脚本（同一 `--menu`，不同 `--restrictions` / `--protein` / `--budget`），再合并；多轮运行合并在**一次 Bash 调用**内完成（Speed 规则 3）。
- 低卡场景（场景 4）：`--protein` 传用户可接受的最低蛋白下限；需要热量优先时参考场景 4 的排序说明。
- 脚本细节见 `references/mcd_mcp.md`。

### 5. Format the output

按 Output Format (动态格式规范) 呈现：四要素齐全（推荐组合带价格、核心营养、实操建议、门店信息），语言组织随场景变化。

若 `status` 不是 `ok`，走场景 5 无解兜底：给出最接近的备选 + 差距说明 + 可调选项。

## Speed Optimization Rules (极速执行规则)

**本节优先级高于其他所有章节，执行时严格遵守。目标：一次推荐任务总耗时控制在 3 分钟内。**

### 规则 1：禁止自行处理数据

拉取到 `mcd_nutrition`（营养文本）和 `mcd_prices`（门店价格）之后，**绝对禁止**自己写 Python 代码 / 内联脚本去合并这两个文件、清洗数据或做名称匹配。合并、匹配、清洗**全部是 `scripts/recommend.py` 的工作**——你只负责把原始数据原样落盘成文件，然后**直接把文件路径作为 `--menu` / `--prices` 参数传给脚本**。唯一允许的数据准备动作是：把工具返回的原始内容用一次 `Write`/一次 heredoc 写入文件。

### 规则 2：禁止长篇大论的内心独白

不要向用户输出「我正在进行第一步…现在第二步…」的过程性叙述。正确节奏：**拿到数据 → 静默调用脚本 → 拿到结果直接输出最终结论**。中间只有一次简短开场（说明识别到的约束/场景），其余全部静默执行。异常需要降级时才简短说明。

### 规则 3：简化工具调用

- `query-meals` **只调用一次**，其返回已包含全部分类和全量餐品价格——**严禁**为不同类目/池子反复循环调用子工具（query-meal-detail 等仅在「推荐结果必须确认组成」时才补调，且能并行就并行）。
- 数据拉取一律并行（见 Workflow 步骤 2）；`calculate-price` 只对**最终确认的 1–2 个组合**核算，不对所有候选逐一核算。
- 脚本多轮运行（如优先级分轮）应合并在**一次 Bash 调用**里串行执行，不要每轮各发一次工具调用。

## Critical Rules

> **以下三条（Speed 规则）为最高优先级，与任何其他规则冲突时以它们为准：**
>
> 1. **禁止自行处理数据**：mcd_nutrition 与 mcd_prices 拉取后，合并/清洗/匹配必须交给 `scripts/recommend.py`，严禁自己写代码处理，文件路径直接作参数传入。
> 2. **禁止过程性叙述**：不输出分步骤思考过程；静默调用脚本，拿到结果直接输出最终结论。
> 3. **简化工具调用**：`query-meals` 只调一次拿全量价格，禁止后台循环调用各类目子工具；并行拉取，`calculate-price` 仅核算最终组合。

- **Never fabricate prices or nutrition.** Missing data is surfaced, not guessed.
- mcd-mcp is the single source of truth for all numbers.
- **组合枚举与营养/价格加总必须由 `recommend.py` 完成，严禁脑内暴力枚举或心算**；数据获取工具必须并行调用。
- Restrictions are exclusion keywords matched against item name; verify the excluded items actually contain the forbidden ingredient before reporting success.
- Menus and nutrition lists use slightly different item names (e.g. 吉士汉堡包 vs 吉士汉堡). The script does base-name matching (size/packaging qualifiers ignored); items that cannot be priced are treated as not orderable, never guessed.
- 场景 2 的优先级无法满足时，必须诚实告知，不得以次充好。

## Resources

- `scripts/recommend.py` — deterministic combo selector (text/JSON nutrition parsing, price merging, constraint satisfaction + scoring).
- `references/mcd_mcp.md` — mcd-mcp tool inventory, data formats, store/price flow, and the selection algorithm.

## Troubleshooting

- **No mcd-mcp tools found:** The mcd-mcp server is not connected in this session. Tell the user to enable the McDonald's MCP connector, then retry. Do not proceed with hardcoded data.
- **配置前提（Token 归属）:** 本 Skill 不包含任何 Token。用户必须在自己的 WorkBuddy 中配置麦当劳 MCP 连接器，并使用本人手机号在 open.mcd.cn/mcp 申请 Token。优惠券查询结果取决于当前 Token 所属账户，与其他用户无关。
- **Store query fails / no favorites:** Ask the user for a city + location keyword and retry with `searchType=2`.
- **Price matching is partial:** Items whose names don't match the nutrition list stay unpriced; if the best combo then lacks a price, the script returns `no_price_data` — relay that and offer `calculate-price` for an exact total once items are confirmed.
- **Scenario tool missing:** 优惠券接口（`query-promotions` / `query-store-coupons`）不可用时，退回直购价并告知用户「当前无法核算券后价」。
