# mcd-mcp Interface & Selection Logic

This reference documents the real mcd-mcp tools, their data formats, the
store/price flow, and the exact selection/scoring algorithm. Loaded only when
needed, keeping SKILL.md lean.

## 1. Tool inventory (verified)

mcd-mcp is an external MCP server. Its tools appear as `mcp__mcd-mcp__*`.
The ones this skill uses:

| Tool | Params | Purpose |
|---|---|---|
| `list-nutrition-foods` | none | Nutrition (energy/protein/fat/carbs/sodium/calcium) for ~160 common items. **Source of all nutrition numbers.** |
| `query-nearby-stores` | `beType` (1=到店自取, 5=得来速), `searchType` (1=收藏, 2=按位置), `city`+`keyword` (when searchType=2) | Get a `storeCode` (and `beCode` for beType=5). |
| `query-meals` | `storeCode`, `orderType` (1=到店, 2=外送), `beType`, optional `beCode` | Per-store menu with item `code`, names and **prices**. |
| `calculate-price` | `storeCode`, `orderType`, `beType`, `items[{productCode, quantity, ...}]` | Exact total incl. coupons; prices returned in **分** (divide by 100). |
| `query-meal-detail` | `storeCode`, `orderType`, `beType`, `code` | Optional: combo composition / 特调 options (去酱 etc.). |

If `ToolSearch` finds no `mcd` / `mcdonald` tools, the server is not connected —
stop and ask the user to enable it. Never fall back to hardcoded data.

## 2. Nutrition data format (list-nutrition-foods)

The response `data` field is a **string**, not JSON. Shape:

```
[160]{productName,nutritionDescription,energyKj,energyKcal,protein,fat,carbohydrate,sodium,calcium}:
  猪柳麦满分,null,1288,308,16,16,24,781,213
  板烧鸡腿堡,null,1638,391,23,17,35,1041,93
  ...
```

- Header line declares field order; rows are comma-separated, position-based.
- `nutritionDescription` is usually the literal string `null`.
- Rows with `energyKcal == 0` **and** `protein == 0` are non-food entries
  (e.g. 纯悦 water) — the script drops them.
- The list contains duplicates (same item twice) — the script dedupes by name.
- `recommend.py` parses this format directly via `parse_nutrition_text()`; it
  also accepts the raw JSON envelope (`{"data": "<text>"}`) and plain JSON lists.

## 3. Price flow (store required)

Prices only exist per store, so 总价 requires this chain:

1. `query-nearby-stores` → pick a store, get `storeCode`.
2. `query-meals(storeCode, orderType=1, beType=1)` → menu items with prices.
3. Write `{name, price}` pairs to `mcd_prices.json` for the script.
4. Optional exact total: `calculate-price` with the chosen `productCode`s.

Caveats:
- `query-meals` prices may be in 分. The script's `maybe_convert_fen()` converts
  to 元 when the median price exceeds 300 (a plausible cents threshold) and
  flags it in the output note.
- Nutrition item names and menu item names differ slightly
  (吉士汉堡包 vs 吉士汉堡, 纯牛奶（盒装） vs 纯牛奶(盒装)). `merge_prices()`
  joins on **base-name equality**: normalized names with size/packaging
  qualifiers (大杯/中杯/小杯/盒装) and brackets/quotes removed, so size
  variants share the store price while a genuinely different product
  (双层火腿扒麦满分 vs 火腿扒麦满分) never inherits the wrong price.
  Unmatched nutrition items are treated as not orderable at that store and
  excluded from budget-mode combos.

## 4. Selection & scoring algorithm

1. **Filter** — drop items whose name/category contains any restriction keyword
   (case-insensitive; Chinese substring match).
2. **Enumerate** — all combos of 1..`max_combo` (default 3) distinct items.
3. **Score** — sum protein, carbs, calories, and price (when all items priced).
4. **Select**:
   - Budget mode (prices complete): prefer combos meeting `protein_target`
     AND within `budget`; among those, lowest price → closest protein to
     target → lowest calories. If none: highest-protein combo within budget
     (`below_target`, report gap + minimum price to hit target); if even that
     exceeds budget (`over_budget`).
   - Nutrition-only mode (prices missing): among combos meeting the target,
     lowest calories; else highest protein. Status `no_price_data` when a
     budget was requested but unverifiable.
5. **Advice rules** (keyword-based, applied to selected items):
   - 薯条/fries → 换玉米杯/苹果片降碳水
   - 含糖饮料 (可乐/雪碧/柠檬红茶/雪冰) → 换无糖可乐/鲜萃咖啡/矿泉水
   - 酱/sauce → 分装另放，吃时再蘸
   - 油炸/麦辣/脆汁鸡 → 去皮减油
   - 甜品 (派/新地/旋风/冰淇淋) → 控卡期跳过或分享
   - 蛋白质/热量比 < 0.05 g/kcal → 建议分食或去掉一份配菜

All numeric outputs derive solely from the mcd-mcp data supplied to the script.
