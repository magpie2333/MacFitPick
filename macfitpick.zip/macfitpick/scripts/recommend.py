#!/usr/bin/env python3
"""
MacFitPick combo recommender.

All numeric data comes from mcd-mcp responses passed in as files — this script
NEVER invents prices or nutrition values. It only performs combination /
selection logic and generates eating advice.

Inputs
  --menu    Nutrition data file. Accepts either:
              a) the raw TEXT block returned by mcp__mcd-mcp__list-nutrition-foods
                 (header `[N]{productName,nutritionDescription,energyKj,
                 energyKcal,protein,fat,carbohydrate,sodium,calcium}:`
                 followed by comma-separated rows), or
              b) a JSON list of item objects (name/price/protein/...).
  --prices  Optional JSON file derived from mcp__mcd-mcp__query-meals — a list
            of objects containing a name field and a price field. Merged into
            the nutrition items by normalized name matching.
  --protein Protein target in grams (required).
  --budget  Budget in CNY (optional). Budget checks only run when every item
            has a price; otherwise the script falls back to nutrition-only
            selection and says so.
  --restrictions  Comma-separated exclusion keywords, e.g. "鸡,chicken".
  --max-combo     Max items per combo (default 3).
  --out     Optional path to also write the JSON result.
"""

import argparse
import itertools
import json
import re
import sys

# Field-name aliases so the script tolerates varying JSON shapes (English or
# Chinese keys). Extend here if the server uses other names.
NAME_KEYS = ["name", "productName", "名称", "item", "菜品", "product"]
PRICE_KEYS = ["price", "价格", "cost", "¥", "priceYuan"]
PROTEIN_KEYS = ["protein", "蛋白质", "protein_g"]
CARBS_KEYS = ["carbohydrate", "carbs", "碳水", "carb", "carbs_g"]
CAL_KEYS = ["energyKcal", "calories", "热量", "kcal", "calorie"]
CATEGORY_KEYS = ["category", "分类", "type", "品类"]

ADVICE_RULES = [
    (["薯条", "fries", "薯"],
     "将薯条换成玉米杯或苹果片，可显著降低碳水摄入"),
    (["可乐", "雪碧", "汽水", "cola", "sprite", "奶茶", "柠檬红", "雪冰", "怡泉", "橙"],
     "将含糖饮料换成无糖可乐、鲜萃咖啡或矿泉水，减少空热量"),
    (["酱", "sauce", "蘸"],
     "酱料建议分装、另放，吃时再蘸，避免整包淋上增加脂肪"),
    (["炸", "脆汁鸡", "麦辣", "脆鸡", "fried"],
     "油炸类建议去皮食用，减少油脂"),
    (["鸡块", "nugget", "麦乐鸡"],
     "鸡块本身含油较高，去酱并控制份量更友好"),
    (["派", "新地", "旋风", "冰淇淋", "奶冻", "拉明顿"],
     "甜品热量高且蛋白质低，控卡期建议跳过或与他人分享"),
]


def pick(d, keys):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return None


def to_float(v):
    if v is None:
        return 0.0
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def to_float_or_none(v):
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def find_item_list(obj, depth=0):
    """Depth-first search for the first non-empty list of dicts anywhere in a
    nested response envelope (e.g. {"code":200,"data":{"items":[...]}})."""
    if depth > 5:
        return None
    if isinstance(obj, list):
        return obj if obj and isinstance(obj[0], dict) else None
    if isinstance(obj, dict):
        for v in obj.values():
            found = find_item_list(v, depth + 1)
            if found is not None:
                return found
    return None


def norm_name(s):
    return "".join(str(s).split()).lower()


SIZE_QUALIFIERS = ["超大杯", "大杯", "中杯", "小杯", "盒装"]


def base_name(s):
    """Normalized base product name: strip size/packaging qualifiers,
    brackets, quotes, spaces and trademark marks, then lowercase."""
    s = str(s)
    for q in SIZE_QUALIFIERS:
        s = s.replace(q, "")
    s = re.sub(r"[\s（）()\u3010\u3011\u201c\u201d\"'™®—·・]", "", s)
    return s.lower()


def parse_nutrition_text(text):
    """Parse the raw text block from list-nutrition-foods into item dicts."""
    items, fields = [], None
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith("[") and "{" in line and "}" in line:
            inner = line[line.index("{") + 1: line.rindex("}")]
            fields = [f.strip() for f in inner.split(",")]
            continue
        if fields is None:
            continue
        parts = [p.strip() for p in line.split(",")]
        if len(parts) != len(fields):
            continue
        row = dict(zip(fields, parts))
        name = row.get("productName")
        if not name:
            continue
        kcal = to_float(row.get("energyKcal"))
        protein = to_float(row.get("protein"))
        if kcal == 0 and protein == 0:
            continue  # non-food / zero rows (e.g. 纯悦)
        items.append({
            "name": name,
            "price": None,
            "protein": protein,
            "carbs": to_float(row.get("carbohydrate")),
            "calories": kcal,
            "category": "",
            "_missing_nutrition": False,
        })
    return items


def normalize_json_item(raw):
    return {
        "name": str(pick(raw, NAME_KEYS) or "unknown"),
        "price": to_float_or_none(pick(raw, PRICE_KEYS)),
        "protein": to_float(pick(raw, PROTEIN_KEYS)),
        "carbs": to_float(pick(raw, CARBS_KEYS)),
        "calories": to_float(pick(raw, CAL_KEYS)),
        "category": str(pick(raw, CATEGORY_KEYS) or ""),
        "_missing_nutrition": (
            pick(raw, PROTEIN_KEYS) is None
            or pick(raw, CARBS_KEYS) is None
            or pick(raw, CAL_KEYS) is None
        ),
    }


def load_items(path):
    with open(path, encoding="utf-8") as f:
        content = f.read()
    data = None
    try:
        data = json.loads(content)
    except (json.JSONDecodeError, ValueError):
        data = None
    if isinstance(data, list):
        items = [normalize_json_item(r) for r in data if isinstance(r, dict)]
    elif isinstance(data, dict):
        items = None
        for k in ("items", "menu", "data", "results", "list"):
            if k in data and isinstance(data[k], list):
                items = [normalize_json_item(r) for r in data[k]]
                break
        if items is None and isinstance(data.get("data"), str):
            items = parse_nutrition_text(data["data"])
        if items is None:
            sys.exit("ERROR: JSON menu object must wrap a list or a text 'data' field")
    else:
        items = parse_nutrition_text(content)
    if not items:
        sys.exit("ERROR: no usable items parsed from menu file")
    # Dedupe by normalized name, keep first occurrence
    seen, unique = set(), []
    for it in items:
        key = norm_name(it["name"])
        if key not in seen:
            seen.add(key)
            unique.append(it)
    return unique


def merge_prices(items, price_rows):
    """Join store-menu prices onto nutrition items by base-name equality.

    Base name = normalized name with size/packaging qualifiers (大杯/中杯/
    小杯/盒装) and brackets/quotes/spaces removed, so 可乐中杯↔可乐 and
    纯牛奶（盒装）↔纯牛奶(盒装) match, while a different product like
    双层火腿扒麦满分 can never inherit 火腿扒麦满分's price. Items not on
    the store menu stay unpriced and are treated as not orderable.
    """
    store_index = {}
    for r in price_rows:
        if not isinstance(r, dict):
            continue
        nm = pick(r, NAME_KEYS)
        pr = to_float_or_none(pick(r, PRICE_KEYS))
        if nm and pr is not None:
            store_index.setdefault(base_name(nm), pr)
    if not store_index:
        return 0
    matched = 0
    for it in items:
        key = base_name(it["name"])
        if key in store_index:
            it["price"] = store_index[key]
            matched += 1
    return matched


def maybe_convert_fen(items):
    """query-meals prices may be in 分 (cents). If the median price looks like
    cents (>300), convert to 元 and report it. Returns True if converted."""
    prices = sorted(i["price"] for i in items if i["price"] is not None)
    if not prices:
        return False
    n = len(prices)
    median = prices[n // 2] if n % 2 else (prices[n // 2 - 1] + prices[n // 2]) / 2
    return median > 300


def is_restricted(item, restrictions):
    hay = (item["name"] + " " + item["category"]).lower()
    for r in restrictions:
        if str(r).strip().lower() in hay:
            return True
    return False


def build_advice(combo, totals, target):
    advice = []
    for item in combo:
        hay = item["name"].lower()
        for keys, msg in ADVICE_RULES:
            if any(k.lower() in hay for k in keys):
                advice.append(f"{item['name']}：{msg}")
                break
    if totals["calories"] > 0:
        ratio = totals["protein"] / totals["calories"]
        if ratio < 0.05:  # < ~5g protein per 100 kcal
            advice.append("整体蛋白质/热量比偏低，建议与同伴分食或去掉一份配菜")
    if totals["protein"] >= target and totals["calories"] > 700:
        advice.append("已达蛋白质目标，若控卡可去掉一份高热量配菜")
    seen, out = set(), []
    for a in advice:
        if a not in seen:
            seen.add(a)
            out.append(a)
    return out


def main():
    ap = argparse.ArgumentParser(description="MacFitPick combo recommender")
    ap.add_argument("--menu", required=True,
                    help="Nutrition file: list-nutrition-foods text block or JSON list")
    ap.add_argument("--prices", default=None,
                    help="Optional JSON file of prices from query-meals")
    ap.add_argument("--protein", type=float, required=True, help="Protein target (g)")
    ap.add_argument("--budget", type=float, default=None, help="Budget (CNY)")
    ap.add_argument("--restrictions", default="", help="Comma-separated exclusion keywords")
    ap.add_argument("--max-combo", type=int, default=3, help="Max items per combo")
    ap.add_argument("--out", default=None, help="Optional path to write JSON result")
    args = ap.parse_args()

    target = args.protein
    restrictions = [r.strip() for r in args.restrictions.split(",") if r.strip()]

    items = load_items(args.menu)
    price_note = ""
    if args.prices:
        with open(args.prices, encoding="utf-8") as f:
            price_rows = json.load(f)
        price_rows = find_item_list(price_rows) or []
        matched = merge_prices(items, price_rows)
        if matched and maybe_convert_fen(items):
            for it in items:
                if it["price"] is not None:
                    it["price"] /= 100.0
            price_note = " 价格原始单位为分，已自动换算为元。"
        if matched:
            # Items without a store price are not orderable at this store right
            # now — exclude them from combo search instead of failing to budget.
            unpriced = [i["name"] for i in items if i["price"] is None]
            items = [i for i in items if i["price"] is not None]
            if unpriced:
                price_note += f" 已按门店在售菜单过滤 {len(unpriced)} 项当前不可点餐品。"

    items = [i for i in items if not is_restricted(i, restrictions)]
    if not items:
        sys.exit("ERROR: all items filtered out by restrictions")

    prices_complete = all(i["price"] is not None for i in items)
    use_budget = args.budget is not None and prices_complete

    # Enumerate combos
    candidates = []
    for size in range(1, args.max_combo + 1):
        for combo in itertools.combinations(items, size):
            tp = sum(i["protein"] for i in combo)
            tcal = sum(i["calories"] for i in combo)
            tcarb = sum(i["carbs"] for i in combo)
            tprice = sum(i["price"] for i in combo if i["price"] is not None)
            candidates.append({
                "combo": list(combo), "protein": tp, "price": tprice,
                "carbs": tcarb, "calories": tcal,
                "meets": tp >= target,
                "within": (tprice <= args.budget) if use_budget else True,
            })

    if not candidates:
        sys.exit("ERROR: no combos generated")

    if use_budget:
        valid = [c for c in candidates if c["meets"] and c["within"]]
        if valid:
            best = min(valid, key=lambda c: (c["price"], abs(c["protein"] - target), c["calories"]))
            status = "ok"
            note = "已满足蛋白质目标且在预算内。"
        else:
            within = [c for c in candidates if c["within"]]
            if within:
                best = max(within, key=lambda c: c["protein"])
                status = "below_target"
                meets_prices = [c["price"] for c in candidates if c["meets"]]
                min_price = min(meets_prices) if meets_prices else None
                gap = max(0.0, target - best["protein"])
                note = (f"预算内无法达到蛋白质目标，当前最高约 {best['protein']:.0f}g，"
                        f"缺口约 {gap:.0f}g。")
                if min_price is not None:
                    note += f"达到目标至少需 ¥{min_price:.0f}（可能超出预算）。"
            else:
                best = min(candidates, key=lambda c: c["price"])
                status = "over_budget"
                note = "即使最低价组合也超出预算，请提高预算或放宽目标/忌口。"
    else:
        valid = [c for c in candidates if c["meets"]]
        if valid:
            best = min(valid, key=lambda c: (c["calories"], len(c["combo"])))
            status = "ok"
        else:
            best = max(candidates, key=lambda c: c["protein"])
            status = "below_target"
        if args.budget is not None:
            status = "no_price_data"
            note = ("所选门店菜单未匹配到全部价格，无法校验预算；"
                    "以下为按营养选出的组合，总价需在确认门店后用 calculate-price 核算。")
            if best["protein"] < target:
                note += f" 且当前组合蛋白质约 {best['protein']:.0f}g，未达目标 {target:.0f}g。"
        else:
            note = "未提供预算，仅按蛋白质目标与热量优选。"

    advice = build_advice(best["combo"], best, target)
    missing = [i["name"] for i in best["combo"] if i["_missing_nutrition"]]
    if missing:
        note += f" 注意：以下餐品缺少营养数据：{', '.join(missing)}。"

    result = {
        "items": [
            {
                "name": i["name"],
                "price": round(i["price"], 2) if i["price"] is not None else None,
                "protein": round(i["protein"], 1),
                "carbs": round(i["carbs"], 1),
                "calories": round(i["calories"], 1),
            }
            for i in best["combo"]
        ],
        "total_price": round(best["price"], 2) if use_budget else None,
        "totals": {
            "protein": round(best["protein"], 1),
            "carbs": round(best["carbs"], 1),
            "calories": round(best["calories"], 1),
        },
        "meets_protein_target": best["meets"],
        "within_budget": best["within"] if use_budget else None,
        "status": status,
        "advice": advice,
        "note": (note + price_note).strip(),
    }

    print(json.dumps(result, ensure_ascii=False, indent=2))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
